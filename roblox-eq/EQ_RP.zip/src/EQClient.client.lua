-- EQClient (LocalScript)
-- Miejsce: StarterPlayer > StarterPlayerScripts > EQClient
-- Rysuje cały interfejs ekwipunku RP (nie trzeba nic budować w StarterGui).

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local StarterGui = game:GetService("StarterGui")
local Lighting = game:GetService("Lighting")

local player = Players.LocalPlayer
local Shared = ReplicatedStorage:WaitForChild("EQShared")
local Config = require(Shared:WaitForChild("EQConfig"))
local Items = require(Shared:WaitForChild("ItemData"))
local Remotes = ReplicatedStorage:WaitForChild("EQRemotes")
local UpdateEvent = Remotes:WaitForChild("InventoryUpdate")
local ActionEvent = Remotes:WaitForChild("InventoryAction")
local NotifyEvent = Remotes:WaitForChild("Notify")

local T = Config.Theme
local MAX = Config.MaxStacks
local WHITE = Color3.new(1, 1, 1)

-- wyłącz domyślny plecak Robloxa
task.spawn(function()
	for _ = 1, 30 do
		if pcall(StarterGui.SetCoreGuiEnabled, StarterGui, Enum.CoreGuiType.Backpack, false) then
			break
		end
		task.wait(0.5)
	end
end)

local state = {
	slots = table.create(MAX, false),
	equipped = 0,
	weight = 0,
	maxWeight = Config.MaxWeight,
	open = false,
	selected = nil,
	search = "",
	category = "all",
}

-- ════════════════════════ pomocnicze ════════════════════════
local function create(class, props)
	local parent = props.Parent
	props.Parent = nil
	local o = Instance.new(class)
	for k, v in pairs(props) do
		o[k] = v
	end
	if parent then
		o.Parent = parent
	end
	return o
end

local function corner(p, r)
	return create("UICorner", { CornerRadius = r and UDim.new(0, r) or UDim.new(1, 0), Parent = p })
end

local function stroke(p, tr, th)
	return create("UIStroke", {
		Color = WHITE,
		Transparency = tr or 0.88,
		Thickness = th or 1,
		ApplyStrokeMode = Enum.ApplyStrokeMode.Border,
		Parent = p,
	})
end

local function label(props)
	props.BackgroundTransparency = 1
	props.Font = props.Font or Enum.Font.GothamMedium
	props.TextColor3 = props.TextColor3 or T.Text
	props.TextSize = props.TextSize or 14
	return create("TextLabel", props)
end

local function tween(o, t, props)
	local tw = TweenService:Create(o, TweenInfo.new(t, Enum.EasingStyle.Quint, Enum.EasingDirection.Out), props)
	tw:Play()
	return tw
end

local function act(action, a, b)
	ActionEvent:FireServer(action, a, b)
end

local function rarityOf(id)
	local d = Items[id]
	return Config.Rarities[d and d.Rarity or "Common"] or Config.Rarities.Common
end

local function categoryName(id)
	for _, c in Config.Categories do
		if c.Id == id then
			return c.Name
		end
	end
	return id or "Różne"
end

local function setIcon(img, txt, id)
	local def = Items[id]
	if def and def.Icon and def.Icon ~= "" then
		img.Image = def.Icon
		img.Visible = true
		txt.Text = ""
	else
		img.Visible = false
		txt.Text = def and def.Emoji or "📦"
	end
end

local function kg(n)
	return (("%.1f"):format(n)):gsub("%.", ",", 1) .. " kg"
end

-- ════════════════════════ wymiary ════════════════════════
local PAD = 24
local CARD_W, CARD_H, CARD_GAP, COLS, ROWS = 118, 104, 10, 4, 3
local GRID_W = COLS * CARD_W + (COLS - 1) * CARD_GAP + 10
local GRID_H = ROWS * CARD_H + (ROWS - 1) * CARD_GAP + 4
local DET_W = 280
local GRID_Y = 156
local PANEL_W = PAD + GRID_W + 20 + DET_W + PAD
local PANEL_H = GRID_Y + GRID_H + 62

-- ════════════════════════ GUI ════════════════════════
local gui = create("ScreenGui", {
	Name = "EQGui",
	ResetOnSpawn = false,
	ZIndexBehavior = Enum.ZIndexBehavior.Sibling,
	DisplayOrder = 10,
	Parent = player:WaitForChild("PlayerGui"),
})

local blur
if Config.Blur then
	blur = create("BlurEffect", { Name = "EQBlur", Size = 0, Enabled = false, Parent = Lighting })
end

local panel = create("Frame", {
	Name = "Ekwipunek",
	AnchorPoint = Vector2.new(0.5, 0.5),
	Position = UDim2.fromScale(0.5, 0.5),
	Size = UDim2.fromOffset(PANEL_W, PANEL_H),
	BackgroundColor3 = T.Panel,
	BackgroundTransparency = T.PanelTransparency,
	Visible = false,
	Parent = gui,
})
corner(panel, 18)
stroke(panel, 0.86, 1)
local panelScale = create("UIScale", { Parent = panel })

-- nagłówek
label({
	Position = UDim2.fromOffset(PAD, 22),
	Size = UDim2.fromOffset(300, 28),
	Text = "EKWIPUNEK",
	TextSize = 24,
	Font = Enum.Font.GothamBlack,
	TextXAlignment = Enum.TextXAlignment.Left,
	Parent = panel,
})

local closeBtn = create("TextButton", {
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -20, 0, 18),
	Size = UDim2.fromOffset(36, 36),
	BackgroundColor3 = T.Glass,
	BackgroundTransparency = 0.92,
	Text = "✕",
	TextSize = 18,
	Font = Enum.Font.GothamBold,
	TextColor3 = T.Text,
	AutoButtonColor = false,
	Parent = panel,
})
corner(closeBtn, 10)
stroke(closeBtn, 0.85)

local searchBox = create("TextBox", {
	Position = UDim2.fromOffset(PAD, 64),
	Size = UDim2.fromOffset(240, 34),
	BackgroundColor3 = T.Glass,
	BackgroundTransparency = 0.93,
	PlaceholderText = "Szukaj...",
	PlaceholderColor3 = T.Muted,
	Text = "",
	TextSize = 14,
	Font = Enum.Font.GothamMedium,
	TextColor3 = T.Text,
	ClearTextOnFocus = false,
	TextXAlignment = Enum.TextXAlignment.Left,
	Parent = panel,
})
corner(searchBox, 9)
stroke(searchBox, 0.9)
create("UIPadding", { PaddingLeft = UDim.new(0, 12), PaddingRight = UDim.new(0, 12), Parent = searchBox })

-- zakładki
local tabsFrame = create("Frame", {
	Position = UDim2.fromOffset(PAD, 112),
	Size = UDim2.fromOffset(GRID_W, 30),
	BackgroundTransparency = 1,
	Parent = panel,
})
create("UIListLayout", {
	FillDirection = Enum.FillDirection.Horizontal,
	VerticalAlignment = Enum.VerticalAlignment.Center,
	Padding = UDim.new(0, 8),
	SortOrder = Enum.SortOrder.LayoutOrder,
	Parent = tabsFrame,
})
local tabButtons = {}
local renderAll -- forward

for i, cat in Config.Categories do
	local b = create("TextButton", {
		LayoutOrder = i,
		AutomaticSize = Enum.AutomaticSize.X,
		Size = UDim2.fromOffset(0, 30),
		BackgroundColor3 = T.Glass,
		BackgroundTransparency = 0.9,
		Text = cat.Name,
		TextSize = 13,
		Font = Enum.Font.GothamBold,
		TextColor3 = T.Text,
		AutoButtonColor = false,
		Parent = tabsFrame,
	})
	corner(b)
	create("UIPadding", { PaddingLeft = UDim.new(0, 14), PaddingRight = UDim.new(0, 14), Parent = b })
	tabButtons[cat.Id] = b
	b.Activated:Connect(function()
		state.category = cat.Id
		renderAll()
	end)
end

-- siatka przedmiotów
local grid = create("ScrollingFrame", {
	Position = UDim2.fromOffset(PAD, GRID_Y),
	Size = UDim2.fromOffset(GRID_W, GRID_H),
	BackgroundTransparency = 1,
	BorderSizePixel = 0,
	ScrollBarThickness = 4,
	ScrollBarImageColor3 = WHITE,
	ScrollBarImageTransparency = 0.7,
	CanvasSize = UDim2.new(),
	AutomaticCanvasSize = Enum.AutomaticSize.Y,
	ScrollingDirection = Enum.ScrollingDirection.Y,
	Parent = panel,
})
create("UIPadding", { PaddingTop = UDim.new(0, 2), PaddingLeft = UDim.new(0, 2), PaddingBottom = UDim.new(0, 2), Parent = grid })
create("UIGridLayout", {
	CellSize = UDim2.fromOffset(CARD_W, CARD_H),
	CellPadding = UDim2.fromOffset(CARD_GAP, CARD_GAP),
	SortOrder = Enum.SortOrder.LayoutOrder,
	Parent = grid,
})
local emptyLabel = label({
	Position = UDim2.fromOffset(PAD, GRID_Y),
	Size = UDim2.fromOffset(GRID_W, GRID_H),
	Text = "Brak przedmiotów",
	TextSize = 15,
	TextColor3 = T.Muted,
	Visible = false,
	Parent = panel,
})

-- panel szczegółów
local details = create("Frame", {
	Position = UDim2.fromOffset(PAD + GRID_W + 20, GRID_Y),
	Size = UDim2.fromOffset(DET_W, GRID_H),
	BackgroundColor3 = T.Glass,
	BackgroundTransparency = 0.95,
	Parent = panel,
})
corner(details, 14)
stroke(details, 0.9)

local detEmpty = label({
	Size = UDim2.fromScale(1, 1),
	Text = "Wybierz przedmiot",
	TextSize = 15,
	TextColor3 = T.Muted,
	Parent = details,
})
local detContent = create("Frame", { Size = UDim2.fromScale(1, 1), BackgroundTransparency = 1, Visible = false, Parent = details })
local detImg = create("ImageLabel", {
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 26),
	Size = UDim2.fromOffset(52, 52),
	BackgroundTransparency = 1,
	ScaleType = Enum.ScaleType.Fit,
	Visible = false,
	Parent = detContent,
})
local detEmoji = label({
	AnchorPoint = Vector2.new(0.5, 0),
	Position = UDim2.new(0.5, 0, 0, 26),
	Size = UDim2.fromOffset(52, 52),
	TextScaled = true,
	Text = "",
	Parent = detContent,
})
local detName = label({
	Position = UDim2.fromOffset(12, 90),
	Size = UDim2.new(1, -24, 0, 28),
	Text = "",
	TextSize = 22,
	Font = Enum.Font.GothamBlack,
	TextTruncate = Enum.TextTruncate.AtEnd,
	Parent = detContent,
})
local detRarity = label({
	Position = UDim2.fromOffset(12, 118),
	Size = UDim2.new(1, -24, 0, 16),
	Text = "",
	TextSize = 12,
	Font = Enum.Font.GothamBlack,
	Parent = detContent,
})
local detDesc = label({
	Position = UDim2.fromOffset(18, 144),
	Size = UDim2.new(1, -36, 0, 36),
	Text = "",
	TextSize = 13,
	TextColor3 = T.SubText,
	TextWrapped = true,
	TextYAlignment = Enum.TextYAlignment.Top,
	Parent = detContent,
})
local detMeta = label({
	Position = UDim2.fromOffset(12, 186),
	Size = UDim2.new(1, -24, 0, 16),
	Text = "",
	TextSize = 12,
	TextColor3 = T.Muted,
	Parent = detContent,
})
local detCat = label({
	Position = UDim2.fromOffset(12, 203),
	Size = UDim2.new(1, -24, 0, 16),
	Text = "",
	TextSize = 12,
	TextColor3 = T.Muted,
	Parent = detContent,
})

local function makeBtn(text, bg, fg, pos, size)
	local b = create("TextButton", {
		Position = pos,
		Size = size,
		BackgroundColor3 = bg,
		Text = text,
		TextSize = 15,
		Font = Enum.Font.GothamBold,
		TextColor3 = fg,
		AutoButtonColor = true,
		Parent = detContent,
	})
	corner(b, 9)
	return b
end
local BW = DET_W - 32
local btnUse = makeBtn("Użyj", T.Primary, T.PrimaryText, UDim2.fromOffset(16, GRID_H - 106), UDim2.fromOffset(BW, 40))
local btnDrop = makeBtn("Wyrzuć", T.Secondary, T.Text, UDim2.fromOffset(16, GRID_H - 58), UDim2.fromOffset(math.floor((BW - 8) / 2), 40))
local btnGive = makeBtn("Podaj", T.Secondary, T.Text, UDim2.fromOffset(16 + math.floor((BW - 8) / 2) + 8, GRID_H - 58), UDim2.fromOffset(math.floor((BW - 8) / 2), 40))
btnGive.TextSize = 13
btnGive.TextTruncate = Enum.TextTruncate.AtEnd

-- dół: waga
local weightBg = create("Frame", {
	Position = UDim2.fromOffset(PAD, GRID_Y + GRID_H + 22),
	Size = UDim2.fromOffset(330, 6),
	BackgroundColor3 = T.Glass,
	BackgroundTransparency = 0.85,
	BorderSizePixel = 0,
	Parent = panel,
})
corner(weightBg)
local weightFill = create("Frame", {
	Size = UDim2.fromScale(0, 1),
	BackgroundColor3 = WHITE,
	BorderSizePixel = 0,
	Parent = weightBg,
})
corner(weightFill)
local weightLabel = label({
	Position = UDim2.fromOffset(PAD, GRID_Y + GRID_H + 32),
	Size = UDim2.fromOffset(200, 16),
	Text = "0 / 50 kg",
	TextSize = 12,
	TextColor3 = T.SubText,
	TextXAlignment = Enum.TextXAlignment.Left,
	Parent = panel,
})
label({
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -PAD, 0, GRID_Y + GRID_H + 26),
	Size = UDim2.fromOffset(200, 16),
	Text = "[" .. Config.ToggleKey.Name .. "] zamknij",
	TextSize = 12,
	TextColor3 = T.Muted,
	TextXAlignment = Enum.TextXAlignment.Right,
	Parent = panel,
})

-- przycisk otwierania (telefon)
local openBtn
if Config.ShowOpenButton then
	openBtn = create("TextButton", {
		AnchorPoint = Vector2.new(0, 0.5),
		Position = UDim2.new(0, 14, 0.5, 0),
		Size = UDim2.fromOffset(54, 54),
		BackgroundColor3 = T.Panel,
		BackgroundTransparency = 0.2,
		Text = "🎒",
		TextSize = 26,
		Font = Enum.Font.GothamBold,
		TextColor3 = T.Text,
		AutoButtonColor = true,
		Parent = gui,
	})
	corner(openBtn, 14)
	stroke(openBtn, 0.8)
	label({
		AnchorPoint = Vector2.new(1, 1),
		Position = UDim2.new(1, -5, 1, -2),
		Size = UDim2.fromOffset(16, 14),
		Text = Config.ToggleKey.Name,
		TextSize = 11,
		Font = Enum.Font.GothamBold,
		TextColor3 = T.Muted,
		TextXAlignment = Enum.TextXAlignment.Right,
		Parent = openBtn,
	})
end

-- powiadomienia
local toasts = create("Frame", {
	AnchorPoint = Vector2.new(1, 0),
	Position = UDim2.new(1, -16, 0, 16),
	Size = UDim2.fromOffset(280, 300),
	BackgroundTransparency = 1,
	Parent = gui,
})
local toastScale = create("UIScale", { Parent = toasts })
create("UIListLayout", {
	VerticalAlignment = Enum.VerticalAlignment.Top,
	HorizontalAlignment = Enum.HorizontalAlignment.Right,
	Padding = UDim.new(0, 6),
	SortOrder = Enum.SortOrder.LayoutOrder,
	Parent = toasts,
})

-- ════════════════════════ karty ════════════════════════
local cards = {}
local lastClick = { slot = nil, t = 0 }

local function styleCard(c)
	local selected = c.slot ~= nil and c.slot == state.selected
	local equipped = c.slot ~= nil and c.slot == state.equipped
	local tr = selected and 0.8 or (c.hover and 0.9 or 0.94)
	tween(c.btn, 0.12, { BackgroundTransparency = tr })
	c.stroke.Transparency = selected and 0.35 or (equipped and 0.5 or 0.9)
	c.stroke.Thickness = selected and 1.5 or 1
	c.equip.Visible = equipped
end

local function onCardClick(c)
	local slot = c.slot
	if not slot then
		return
	end
	local t = os.clock()
	if lastClick.slot == slot and t - lastClick.t < 0.35 then
		lastClick.slot = nil
		act("Use", slot)
		return
	end
	lastClick.slot = slot
	lastClick.t = t
	state.selected = slot
	renderAll()
end

local function getCard(k)
	if cards[k] then
		return cards[k]
	end
	local btn = create("TextButton", {
		Text = "",
		AutoButtonColor = false,
		BackgroundColor3 = T.Glass,
		BackgroundTransparency = 0.94,
		LayoutOrder = k,
		Parent = grid,
	})
	corner(btn, 10)
	local st = stroke(btn, 0.9)
	local img = create("ImageLabel", {
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.new(0.5, 0, 0, 40),
		Size = UDim2.fromOffset(38, 38),
		BackgroundTransparency = 1,
		ScaleType = Enum.ScaleType.Fit,
		Visible = false,
		Parent = btn,
	})
	local emoji = label({
		AnchorPoint = Vector2.new(0.5, 0.5),
		Position = UDim2.new(0.5, 0, 0, 40),
		Size = UDim2.fromOffset(36, 36),
		TextScaled = true,
		Text = "",
		Parent = btn,
	})
	local name = label({
		Position = UDim2.fromOffset(6, 68),
		Size = UDim2.new(1, -12, 0, 16),
		Text = "",
		TextSize = 12,
		TextTruncate = Enum.TextTruncate.AtEnd,
		Parent = btn,
	})
	local amount = label({
		AnchorPoint = Vector2.new(1, 0),
		Position = UDim2.new(1, -8, 0, 6),
		Size = UDim2.fromOffset(40, 14),
		Text = "",
		TextSize = 12,
		Font = Enum.Font.GothamBold,
		TextXAlignment = Enum.TextXAlignment.Right,
		Parent = btn,
	})
	local equip = label({
		Position = UDim2.fromOffset(8, 6),
		Size = UDim2.fromOffset(40, 14),
		Text = "W RĘCE",
		TextSize = 9,
		Font = Enum.Font.GothamBlack,
		TextColor3 = T.SubText,
		TextXAlignment = Enum.TextXAlignment.Left,
		Visible = false,
		Parent = btn,
	})
	local bar = create("Frame", {
		AnchorPoint = Vector2.new(0.5, 1),
		Position = UDim2.new(0.5, 0, 1, -9),
		Size = UDim2.new(1, -26, 0, 3),
		BorderSizePixel = 0,
		Parent = btn,
	})
	corner(bar)
	local c = { btn = btn, stroke = st, img = img, emoji = emoji, name = name, amount = amount, bar = bar, equip = equip, slot = nil, hover = false }
	btn.Activated:Connect(function()
		onCardClick(c)
	end)
	btn.MouseEnter:Connect(function()
		c.hover = true
		styleCard(c)
	end)
	btn.MouseLeave:Connect(function()
		c.hover = false
		styleCard(c)
	end)
	cards[k] = c
	return c
end

-- ════════════════════════ rysowanie ════════════════════════
local function visibleSlots()
	local list = {}
	for i = 1, MAX do
		local s = state.slots[i]
		local def = s and Items[s.id]
		if def then
			local catOk = state.category == "all" or def.Category == state.category
			local searchOk = state.search == ""
				or string.find(string.lower(def.Name), state.search, 1, true) ~= nil
				or string.find(string.lower(s.id), state.search, 1, true) ~= nil
			if catOk and searchOk then
				table.insert(list, i)
			end
		end
	end
	return list
end

local function nearestPlayer()
	local myRoot = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not myRoot then
		return nil
	end
	local best, bestDist = nil, Config.GiveDistance
	for _, other in Players:GetPlayers() do
		if other ~= player then
			local r = other.Character and other.Character:FindFirstChild("HumanoidRootPart")
			if r then
				local d = (r.Position - myRoot.Position).Magnitude
				if d <= bestDist then
					best, bestDist = other, d
				end
			end
		end
	end
	return best
end

local function renderGive()
	local target = nearestPlayer()
	btnGive.Text = target and ("Podaj: " .. target.DisplayName) or "Podaj (nikt obok)"
	btnGive.TextTransparency = target and 0 or 0.55
	return target
end

local function renderDetails()
	local i = state.selected
	local s = i and state.slots[i]
	local def = s and Items[s.id]
	if not def then
		detEmpty.Visible = true
		detContent.Visible = false
		return
	end
	detEmpty.Visible = false
	detContent.Visible = true
	local r = rarityOf(s.id)
	setIcon(detImg, detEmoji, s.id)
	detName.Text = def.Name
	detRarity.Text = r.Name
	detRarity.TextColor3 = r.Color
	detDesc.Text = def.Description or ""
	detMeta.Text = ("Ilość: %d   •   Waga: %s"):format(s.n, kg((def.Weight or 0) * s.n))
	detCat.Text = "Kategoria: " .. categoryName(def.Category)

	if def.Type == "Tool" then
		local on = state.equipped == i
		btnUse.Text = on and "Schowaj" or "Weź do ręki"
		btnUse.BackgroundColor3 = T.Primary
		btnUse.TextTransparency = 0
	elseif def.Type == "Consumable" then
		btnUse.Text = "Użyj"
		btnUse.BackgroundColor3 = T.Primary
		btnUse.TextTransparency = 0
	else
		btnUse.Text = "Nie można użyć"
		btnUse.BackgroundColor3 = T.Secondary
		btnUse.TextTransparency = 0.5
	end
	renderGive()
end

function renderAll()
	-- zakładki
	for id, b in tabButtons do
		local active = state.category == id
		b.BackgroundTransparency = active and 0 or 0.9
		b.TextColor3 = active and T.PrimaryText or T.Text
	end
	-- siatka
	local list = visibleSlots()
	local selectedVisible = false
	for k, slot in list do
		local c = getCard(k)
		local s = state.slots[slot]
		local def = Items[s.id]
		local r = rarityOf(s.id)
		c.slot = slot
		c.btn.Visible = true
		setIcon(c.img, c.emoji, s.id)
		c.name.Text = def.Name
		c.amount.Text = "x" .. s.n
		c.bar.BackgroundColor3 = r.Color
		if slot == state.selected then
			selectedVisible = true
		end
	end
	for k = #list + 1, #cards do
		cards[k].slot = nil
		cards[k].btn.Visible = false
	end
	if not selectedVisible then
		state.selected = list[1]
	end
	for k = 1, #list do
		styleCard(cards[k])
	end
	emptyLabel.Visible = #list == 0
	-- waga
	local ratio = state.maxWeight > 0 and math.clamp(state.weight / state.maxWeight, 0, 1) or 0
	tween(weightFill, 0.25, { Size = UDim2.fromScale(ratio, 1) })
	weightFill.BackgroundColor3 = ratio >= 0.9 and T.Danger or WHITE
	weightLabel.Text = ("%s / %d kg"):format((("%.1f"):format(state.weight)):gsub("%.", ",", 1), state.maxWeight)
	renderDetails()
end

-- ════════════════════════ powiadomienia ════════════════════════
local toastOrder = 0
local function toast(text, color)
	toastOrder += 1
	local f = create("Frame", {
		Size = UDim2.fromOffset(280, 40),
		BackgroundColor3 = T.Panel,
		BackgroundTransparency = 1,
		LayoutOrder = toastOrder,
		Parent = toasts,
	})
	corner(f, 10)
	local st = stroke(f, 1)
	local dot = create("Frame", {
		AnchorPoint = Vector2.new(0, 0.5),
		Position = UDim2.new(0, 14, 0.5, 0),
		Size = UDim2.fromOffset(6, 6),
		BackgroundColor3 = color or WHITE,
		BackgroundTransparency = 1,
		BorderSizePixel = 0,
		Parent = f,
	})
	corner(dot)
	local l = label({
		Position = UDim2.fromOffset(30, 0),
		Size = UDim2.new(1, -40, 1, 0),
		Text = text,
		TextSize = 13,
		Font = Enum.Font.GothamBold,
		TextXAlignment = Enum.TextXAlignment.Left,
		TextTruncate = Enum.TextTruncate.AtEnd,
		TextTransparency = 1,
		Parent = f,
	})
	tween(f, 0.25, { BackgroundTransparency = 0.12 })
	tween(st, 0.25, { Transparency = 0.86 })
	tween(dot, 0.25, { BackgroundTransparency = 0 })
	tween(l, 0.25, { TextTransparency = 0 })
	local list = {}
	for _, ch in toasts:GetChildren() do
		if ch:IsA("Frame") then
			table.insert(list, ch)
		end
	end
	table.sort(list, function(a, b)
		return a.LayoutOrder < b.LayoutOrder
	end)
	for k = 1, #list - 5 do
		list[k]:Destroy()
	end
	task.delay(3, function()
		if not f.Parent then
			return
		end
		tween(f, 0.4, { BackgroundTransparency = 1 })
		tween(st, 0.4, { Transparency = 1 })
		tween(dot, 0.4, { BackgroundTransparency = 1 })
		tween(l, 0.4, { TextTransparency = 1 }).Completed:Wait()
		f:Destroy()
	end)
end

-- ════════════════════════ otwieranie / zamykanie ════════════════════════
local function setOpen(open)
	if state.open == open then
		return
	end
	state.open = open
	if open then
		state.selected = nil
		renderAll()
		panel.Visible = true
		panel.Position = UDim2.new(0.5, 0, 0.5, 24)
		tween(panel, 0.28, { Position = UDim2.fromScale(0.5, 0.5) })
		if blur then
			blur.Enabled = true
			tween(blur, 0.3, { Size = 14 })
		end
	else
		searchBox:ReleaseFocus()
		tween(panel, 0.18, { Position = UDim2.new(0.5, 0, 0.5, 24) }).Completed:Once(function()
			if not state.open then
				panel.Visible = false
			end
		end)
		if blur then
			tween(blur, 0.2, { Size = 0 }).Completed:Once(function()
				if not state.open then
					blur.Enabled = false
				end
			end)
		end
	end
end

-- ════════════════════════ przyciski ════════════════════════
btnUse.Activated:Connect(function()
	if state.selected then
		act("Use", state.selected)
	end
end)
btnDrop.Activated:Connect(function()
	if state.selected then
		act("Drop", state.selected, 1)
	end
end)
btnGive.Activated:Connect(function()
	local target = renderGive()
	if state.selected and target then
		act("Give", state.selected, target.UserId)
	end
end)
closeBtn.Activated:Connect(function()
	setOpen(false)
end)
if openBtn then
	openBtn.Activated:Connect(function()
		setOpen(not state.open)
	end)
end
searchBox:GetPropertyChangedSignal("Text"):Connect(function()
	state.search = string.lower(searchBox.Text)
	renderAll()
end)

UserInputService.InputBegan:Connect(function(input, processed)
	if processed then
		return
	end
	if input.KeyCode == Config.ToggleKey then
		setOpen(not state.open)
	end
end)

-- odświeżanie przycisku "Podaj", gdy okno jest otwarte
task.spawn(function()
	while true do
		task.wait(0.5)
		if state.open and state.selected then
			renderGive()
		end
	end
end)

-- skalowanie pod rozmiar ekranu
local function rescale()
	local cam = workspace.CurrentCamera
	if not cam then
		return
	end
	local vp = cam.ViewportSize
	local s = math.clamp(math.min((vp.X - 30) / PANEL_W, (vp.Y - 60) / PANEL_H), 0.45, 1)
	panelScale.Scale = s
	toastScale.Scale = math.clamp(s, 0.7, 1)
end
local function hookCamera()
	local cam = workspace.CurrentCamera
	if cam then
		cam:GetPropertyChangedSignal("ViewportSize"):Connect(rescale)
	end
	rescale()
end
hookCamera()
workspace:GetPropertyChangedSignal("CurrentCamera"):Connect(hookCamera)

-- ════════════════════════ dane z serwera ════════════════════════
UpdateEvent.OnClientEvent:Connect(function(payload)
	if type(payload) ~= "table" or type(payload.slots) ~= "table" then
		return
	end
	for i = 1, MAX do
		local s = payload.slots[i]
		state.slots[i] = (type(s) == "table" and Items[s.id]) and s or false
	end
	state.equipped = payload.equipped or 0
	state.weight = payload.weight or 0
	state.maxWeight = payload.maxWeight or Config.MaxWeight
	if state.selected and not state.slots[state.selected] then
		state.selected = nil
	end
	renderAll()
end)

NotifyEvent.OnClientEvent:Connect(function(text, color)
	toast(text, color)
end)

renderAll()
act("Request")
